<!doctype html>
<html lang="en">
  <head>
    <link href="style.css" rel="stylesheet">
    <!-- Required meta tags -->

    <style>
    .navbar-brand{
    animation-iteration-count:infinite;}

    .nav-items
    </style>

  </head>
  <body>

<?php
echo '

    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color:#0f9d58; ">
    <a class="navbar-brand wow pulse" href="index.php">Fine Knowledge</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="#">About Us </a>
        </li><li class="nav-item active">
          <a class="nav-link" href="#">Contact Us </a>
        </li>
      </ul>
    </div>
  </nav>';
  ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    </body>
</html>
