<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!--Animate Css-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
       <!--Wow JS-->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>


      <script>
           new WOW().init();
      </script>

      <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=PT+Serif&display=swap" rel="stylesheet">




    <title>Hello, world!</title>
  </head>
  <body style="margin-top:70px; font-family: 'PT Serif', serif;" id="main-page">
  <?php
  include "header.php";
  ?>




<center>  <div class="container" style="margin-top:150px">
    <h1 class="display-4">Fullfill All Your Dreams</h1>
    <p class="lead">One Stop Portal Where you will get all help related to education</p>
 </div>
 </center>

<br>



<div class="container" >
  <center><h3>What will you choose</h3>
  <hr>
  <div class="card-deck sibling-fade">
      <div class="card" style="background-color:#f8f7f7; height:500px">
      <div class="card-header">
      <h4 style="color:black">B-Tech</h4>
      </div>
      <div class="card-body">
          <img src="image/b-tech.jpg" class="card-img-top" alt="...">
            <p class="card-text"><br>
              <a href="btech-page.php" class="btn btn-secondary btn-block btn-lg active" role="button" aria-pressed="true">Click me to know about B-Tech</a>
            </p>
      </div>
    </div>
    <div class="card" style="background-color:#f8f7f7; height:500px">
    <div class="card-header">
      <h4  style="color:black">B-Com</h4>
    </div>
    <div class="card-body">
        <img src="image/b-com.jpg" class="card-img-top" alt="...">
          <p class="card-text"><br>
            <a href="#" class="btn btn-secondary btn-block btn-lg active" role="button" aria-pressed="true">Click me to know about B-Com</a>
          </p>
    </div>
    </div>
  </div>
</div>







<br><br>
<?php
  include "footer.php";
 ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
